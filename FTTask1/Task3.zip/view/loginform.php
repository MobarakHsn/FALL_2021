<html>
    <head>
        <link rel="stylesheet" type="text/css" href="../css/css.css">
    </head>
    <body>
        <form action="registrationform.php" method="post">
            <div class="box1">
                <tabel>
                    <tr>
                        <td>
                            <input type="text" placeholder="User Name">
                        </td>
                        <td>
                            <input type="password" placeholder="password">
                        </td>
                        <td>
                            <button class="button1" type="submit" name="login">Login</button>
                        <td>
                        <td>
                            <label>
                                <input type="checkbox"  name="remember"> Remember me
                            </label>
                        </td>
                    </tr>
                </table>
            </div>
        </form>
    </body>
</html>